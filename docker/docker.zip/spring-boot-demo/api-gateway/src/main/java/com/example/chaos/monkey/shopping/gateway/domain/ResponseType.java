package com.example.chaos.monkey.shopping.gateway.domain;

/**
 * @author pariwesh gupta
 */
public enum ResponseType {

    REMOTE_SERVICE, SECOND_TRY, FALLBACK, ERROR;
}
