#!/bin/bash
stress --cpu $1 --timeout $2
