package com.example.chaos.monkey.shopping.bestseller.toys;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * @author pariwesh gupta
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class BestsellerToysApplicationTest {

    @Test
    public void contextLoads() {
    }

}