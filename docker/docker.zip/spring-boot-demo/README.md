
## How to build
1. git clone https://github.com/MrBW/chaos-monkey-spring-boot-demo.git
2. git checkout chaostoolkit
3. docker-compose build docker-base-image
4. mvn clean package
5. docker-compose up




http://192.168.99.100:8081/actuator/chaosmonkey/enable POST call 
bestseller/toys
http://192.168.99.100:8081/toys/bestseller
http://192.168.99.100:8080/startpage
http://192.168.99.100:8080/startpage/cb
http://192.168.99.100:8090/fashion/bestseller

https://docs.chaostoolkit.org/reference/api/experiment/

https://codecentric.github.io/chaos-monkey-spring-boot/1.5.0/#_examples
https://codecentric.github.io/chaos-monkey-spring-boot/2.0.0/