package com.example.chaos.monkey.shopping.gateway.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import reactor.core.publisher.Mono;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;

/**
 * @author pariwesh gupta
 */

//@NoArgsConstructor
//@AllArgsConstructor
//@Data
@JsonPropertyOrder({ "fashionResponse", "toysResponse", "hotDealsResponse", "duration", "statusFashion","statusToys","statusHotDeals" })
public class Startpage {

    public long getDuration() {
		return duration;
	}
	public void setDuration(long duration) {
		this.duration = duration;
	}
	public String getStatusFashion() {
		return statusFashion;
	}
	public void setStatusFashion(String statusFashion) {
		this.statusFashion = statusFashion;
	}
	public String getStatusToys() {
		return statusToys;
	}
	public void setStatusToys(String statusToys) {
		this.statusToys = statusToys;
	}
	public String getStatusHotDeals() {
		return statusHotDeals;
	}
	public void setStatusHotDeals(String statusHotDeals) {
		this.statusHotDeals = statusHotDeals;
	}
	public ProductResponse getFashionResponse() {
		return fashionResponse;
	}
	public void setFashionResponse(ProductResponse fashionResponse) {
		this.fashionResponse = fashionResponse;
	}
	public ProductResponse getToysResponse() {
		return toysResponse;
	}
	public void setToysResponse(ProductResponse toysResponse) {
		this.toysResponse = toysResponse;
	}
	public ProductResponse getHotDealsResponse() {
		return hotDealsResponse;
	}
	public void setHotDealsResponse(ProductResponse hotDealsResponse) {
		this.hotDealsResponse = hotDealsResponse;
	}
	private long duration;
    private String statusFashion;
    private String statusToys;
    private String statusHotDeals;
    private ProductResponse fashionResponse;
    private ProductResponse toysResponse;
    private ProductResponse hotDealsResponse;
}
