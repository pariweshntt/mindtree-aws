package com.example.chaos.monkey.shopping.gateway.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import com.example.chaos.monkey.shopping.domain.Product;

/**
 * @author pariwesh gupta
 */

//@NoArgsConstructor
//@AllArgsConstructor
//@Data
public class ProductResponse {

    public ProductResponse(ResponseType responseType, List<Product> products) {
		super();
		this.responseType = responseType;
		this.products = products;
	}
	public ProductResponse() {
		// TODO Auto-generated constructor stub
	}
	public ResponseType getResponseType() {
		return responseType;
	}
	public void setResponseType(ResponseType responseType) {
		this.responseType = responseType;
	}
	public List<Product> getProducts() {
		return products;
	}
	public void setProducts(List<Product> products) {
		this.products = products;
	}
	private ResponseType responseType;
    private List<Product> products;
}
