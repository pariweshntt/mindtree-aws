package com.example.chaos.monkey.shopping.domain;

/**
 * @author pariwesh gupta
 */
public enum ProductCategory {
    FASHION,TOYS,BOOKS;
}
