package com.example.chaos.monkey.shopping.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author pariwesh gupta
 */
@Data
public class Product {
	Product(){
		
	}
    public Product(long id, String name, ProductCategory category) {
		super();
		this.id = id;
		this.name = name;
		this.category = category;
	}
	private long id;
    private String name;
    private ProductCategory category;

}
